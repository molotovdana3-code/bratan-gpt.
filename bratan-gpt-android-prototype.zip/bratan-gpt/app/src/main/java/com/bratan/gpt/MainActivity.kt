package com.bratan.gpt

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val client = OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) listen() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent { BratanScreen(
            onListen = {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) listen()
                else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            },
            onSpeak = { speak(it) },
            onAsk = { text, server, onState -> askServer(text, server, onState) }
        ) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU")
    }

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говори, брат")
        }
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {}
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!phrase.isNullOrBlank()) {
                    // Send recognized phrase to the screen through a local event.
                    pendingPhrase = phrase
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer?.startListening(intent)
    }

    @Volatile private var pendingPhrase: String? = null

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bratan_reply")
    }

    private fun askServer(text: String, server: String, onState: (String) -> Unit) {
        Thread {
            try {
                val base = server.trim().trimEnd('/')
                val payload = JSONObject().put("message", text).toString()
                val request = Request.Builder().url("$base/chat")
                    .post(payload.toRequestBody(jsonType)).build()
                client.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (!response.isSuccessful) throw Exception("Сервер ответил ${response.code}: $body")
                    val answer = JSONObject(body).optString("reply", "Пустой ответ")
                    runOnUiThread {
                        onState(answer)
                        speak(answer)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { onState("Ошибка: ${e.message ?: "не удалось подключиться"}") }
            }
        }.start()
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    @Composable
    private fun BratanScreen(
        onListen: () -> Unit,
        onSpeak: (String) -> Unit,
        onAsk: (String, String, (String) -> Unit) -> Unit
    ) {
        var server by remember { mutableStateOf("http://10.0.2.2:3000") }
        var message by remember { mutableStateOf("") }
        var reply by remember { mutableStateOf("Ну что, брат, подключаемся?") }
        var busy by remember { mutableStateOf(false) }
        var style by remember { mutableStateOf("Братский") }

        // Speech recognizer result is polled by Compose state; UI also supports typing.
        LaunchedEffect(Unit) {
            while (true) {
                pendingPhrase?.let { message = it; pendingPhrase = null }
                kotlinx.coroutines.delay(250)
            }
        }

        MaterialTheme {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("БРАТАН GPT", style = MaterialTheme.typography.headlineLarge)
                    Text("Голосовой собеседник • прототип", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(22.dp))
                    OutlinedTextField(value = server, onValueChange = { server = it },
                        label = { Text("Адрес сервера") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Text("Манера общения")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Братский", "Строгий диктор", "Пивной обзорщик").forEach {
                            FilterChip(selected = style == it, onClick = { style = it }, label = { Text(it) })
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(value = message, onValueChange = { message = it },
                        label = { Text("Скажи или напиши") }, minLines = 3,
                        modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onListen) { Text("🎙 Говорить") }
                        Button(enabled = message.isNotBlank() && !busy, onClick = {
                            busy = true
                            onAsk(message, server) { result -> reply = result; busy = false }
                        }) { Text(if (busy) "Думаю…" else "Отправить") }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text("ОТВЕТ", style = MaterialTheme.typography.titleMedium)
                    Text(reply, modifier = Modifier.weight(1f).fillMaxWidth()
                        .verticalScroll(rememberScrollState()).padding(top = 8.dp))
                    Button(onClick = { onSpeak(reply) }, enabled = reply.isNotBlank()) {
                        Text("🔊 Повторить")
                    }
                    Text("Это ранний прототип. Для работы нужен свой сервер и API-ключ.",
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 14.dp))
                }
            }
        }
    }
}
