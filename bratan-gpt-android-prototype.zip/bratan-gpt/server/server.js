import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "1mb" }));

const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) {
  console.error("Set OPENAI_API_KEY before starting the server.");
  process.exit(1);
}
const openai = new OpenAI({ apiKey });

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message ?? "").slice(0, 8000);
    if (!message.trim()) return res.status(400).json({ error: "message is required" });

    const result = await openai.responses.create({
      model: "gpt-4.1-mini",
      instructions: "Отвечай по-русски, коротко и разговорно. Будь дружелюбным собеседником. Не утверждай, что являешься реальным человеком или знаменитостью. Если просят голос известного человека, используй только общую пародийную манеру, не выдавая её за настоящий голос.",
      input: message
    });
    res.json({ reply: result.output_text || "Не получилось сформировать ответ." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "AI request failed" });
  }
});

app.listen(3000, "0.0.0.0", () => console.log("Братан GPT server listening on :3000"));
