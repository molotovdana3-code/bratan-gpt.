package com.bratan.gpt

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1B1D25)
private val Accent = Color(0xFFB7F36B)
private val Ink = Color(0xFFF4F4F5)
private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { BratanApp(onSpeak = { speak(it) }) }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU")
    }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bratan_reply") }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BratanApp(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("bratan", 0) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "") ?: "") }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var personality by remember { mutableStateOf(prefs.getString("personality", "Братан") ?: "Братан") }
    var error by remember { mutableStateOf<String?>(null) }
    val messages = remember { mutableStateListOf(ChatMessage("Ну здарова, брат. Я на связи. О чём поговорим?", false)) }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeech(context) { draft = it }
        else error = "Нужен доступ к микрофону для голосового ввода."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onPrimary = Color(0xFF141414), onBackground = Ink, onSurface = Ink
    )) {
        Scaffold(containerColor = Bg, topBar = {
            TopAppBar(
                title = { Column {
                    Text("БРАТАН GPT", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text("Голосовой собеседник", fontSize = 12.sp, color = Color.LightGray)
                }},
                actions = { IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, "Настройки", tint = Ink)
                }},
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
            )
        }, bottomBar = {
            Column(Modifier.fillMaxWidth().background(Bg).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier
                    .fillMaxWidth().background(Panel, RoundedCornerShape(24.dp)).padding(8.dp)) {
                    BasicTextField(
                        value = draft, onValueChange = { draft = it },
                        modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 12.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 16.sp),
                        decorationBox = { inner ->
                            if (draft.isEmpty()) Text("Напиши брату...", color = Color.Gray)
                            inner()
                        }
                    )
                    IconButton(onClick = {
                        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                            startSpeech(context) { draft = it }
                        else permission.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Icon(Icons.Default.Mic, "Голосовой ввод", tint = Accent) }
                    IconButton(enabled = draft.isNotBlank() && !busy, onClick = {
                        val text = draft.trim()
                        draft = ""
                        messages.add(ChatMessage(text, true))
                        busy = true; error = null
                        scope.launch {
                            val reply = askServer(endpoint, personality, messages.toList())
                            if (reply.isSuccess) {
                                val answer = reply.getOrThrow()
                                messages.add(ChatMessage(answer, false)); onSpeak(answer)
                            } else error = reply.exceptionOrNull()?.message ?: "Не удалось получить ответ"
                            busy = false
                        }
                    }) { Icon(Icons.Default.Send, "Отправить", tint = if (draft.isNotBlank()) Accent else Color.Gray) }
                }
                Text("Голосовой ввод использует распознавание речи Android", color = Color.Gray, fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp))
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                    Text("РЕЖИМ ОБЩЕНИЯ", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(10.dp))
                    listOf("Братан", "Спокойный", "Строгий").forEach { mode ->
                        FilterChip(selected = personality == mode, onClick = {
                            personality = mode; prefs.edit().putString("personality", mode).apply()
                        }, label = { Text(mode, fontSize = 11.sp) }, modifier = Modifier.padding(end = 4.dp))
                    }
                }
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { msg ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                            Column(Modifier.widthIn(max = 310.dp).background(
                                if (msg.fromUser) Color(0xFF293322) else Panel,
                                RoundedCornerShape(18.dp)
                            ).padding(14.dp)) {
                                Text(if (msg.fromUser) "ТЫ" else "БРАТАН", color = if (msg.fromUser) Accent else Color.LightGray,
                                    fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(5.dp))
                                Text(msg.text, color = Ink, fontSize = 15.sp)
                            }
                        }
                    }
                    if (busy) item { Text("Братан думает…", color = Accent, modifier = Modifier.padding(8.dp)) }
                    error?.let { msg -> item { Text(msg, color = Color(0xFFFF8A80), fontSize = 12.sp) } }
                }
            }
        }
        if (showSettings) {
            AlertDialog(onDismissRequest = { showSettings = false },
                title = { Text("Настройки подключения") },
                text = { Column {
                    Text("Адрес сервера", fontSize = 12.sp, color = Color.Gray)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = endpoint, onValueChange = { endpoint = it },
                        placeholder = { Text("https://твой-сервер.example") }, singleLine = true)
                    Text("API-ключ хранится на сервере, не в приложении.", fontSize = 11.sp, color = Color.Gray)
                }},
                confirmButton = { TextButton(onClick = {
                    prefs.edit().putString("endpoint", endpoint.trim().trimEnd('/')).apply()
                    showSettings = false
                }) { Text("Сохранить") }},
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Отмена") } }
            )
        }
    }
}

private fun startSpeech(context: android.content.Context, onText: (String) -> Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) return
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Говори, брат")
    }
    try {
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onResults(results: Bundle?) {
                results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onText)
                recognizer.destroy()
            }
            override fun onError(error: Int) { recognizer.destroy() }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    } catch (_: Exception) {}
}

private suspend fun askServer(endpoint: String, personality: String, history: List<ChatMessage>): Result<String> =
    withContext(Dispatchers.IO) {
        if (endpoint.isBlank()) return@withContext Result.failure(IllegalStateException("Сначала укажи адрес сервера в настройках."))
        try {
            val url = URL("$endpoint/chat")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000
                doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val body = JSONObject().put("personality", personality).put("messages", JSONArray().apply {
                history.takeLast(24).forEach { put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text)) }
            }).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val json = JSONObject(response)
            if (code !in 200..299) Result.failure(IllegalStateException(json.optString("error", "Ошибка сервера: $code")))
            else Result.success(json.getString("reply"))
        } catch (e: Exception) {
            Result.failure(IllegalStateException("Не удалось подключиться: ${e.message ?: "проверь интернет и адрес сервера"}"))
        }
    }
