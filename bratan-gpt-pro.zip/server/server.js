import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "64kb" }));

const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) {
  console.error("OPENAI_API_KEY is required");
  process.exit(1);
}
const client = new OpenAI({ apiKey });

const styles = {
  "Братан": "Общайся по-русски как близкий приятель: прямо, живо, с юмором и разговорной лексикой. Не начинай с пустых вступлений.",
  "Спокойный": "Общайся по-русски спокойно, дружелюбно и ясно. Без лишней грубости и без воды.",
  "Строгий": "Общайся по-русски кратко, уверенно и по делу. Если идея плохая — объясни почему прямо."
};

app.get("/health", (_req, res) => res.json({ ok: true, service: "bratan-gpt" }));

app.post("/chat", async (req, res) => {
  try {
    const { messages, personality = "Братан" } = req.body ?? {};
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 24) {
      return res.status(400).json({ error: "messages must contain 1–24 messages" });
    }
    const safeMessages = messages.map((m) => {
      if (!m || !["user", "assistant"].includes(m.role) || typeof m.content !== "string") {
        throw new Error("Invalid message format");
      }
      return { role: m.role, content: m.content.slice(0, 6000) };
    });
    const response = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        { role: "system", content: styles[personality] || styles["Братан"] },
        ...safeMessages
      ],
      temperature: 0.8,
      max_tokens: 700
    });
    res.json({ reply: response.choices[0]?.message?.content || "Что-то я задумался. Повтори, брат." });
  } catch (error) {
    console.error("chat error:", error.message);
    res.status(500).json({ error: "Не удалось получить ответ от модели. Проверь сервер и API-ключ." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`Bratan GPT server listening on ${port}`));
